package model;

public class RelatorioGerencial {
	
	
	
}
