package dao;

import java.util.List;

import model.Setor;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import util.HibernateUtil;

public class SetorDaoImp implements SetorDao {
	public void save(Setor setor) {

		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction t = session.beginTransaction();
		session.save(setor);
		t.commit();
	}

	public Setor getSetor(int id) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		return (Setor) session.load(Setor.class, id);
	}

	public List<Setor> list() {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction t = session.beginTransaction();
		List lista = session.createQuery("from Setor ").list();
		t.commit();
		return lista;
	}

	public void remove(Setor setor) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction t = session.beginTransaction();
		session.delete(setor);
		t.commit();
	}

	public void update(Setor setor) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction t = session.beginTransaction();
		session.update(setor);

		t.commit();
	}

	public List<Setor> pesquisar(Integer ID_CENTRO_CUSTO, String nome) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction t = session.beginTransaction();
		Query query = session
				.createQuery("FROM Setor u where u.ID_CENTRO_CUSTO = :id_centro_custo OR u.NOME = :nome"); // mondar
																										// query
																										// para
																										// lyke
		query.setParameter("id_centro_custo", ID_CENTRO_CUSTO);																								// depois
		query.setParameter("nome", nome);
		t.commit();
		return query.list();

	}
}
