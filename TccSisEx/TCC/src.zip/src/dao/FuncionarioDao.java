package dao;

import model.Funcionario;
import java.util.List;

public interface FuncionarioDao {

	public void save(Funcionario funcionario);

	public Funcionario getFuncionario(int id);

	public List<Funcionario> list();

	public void remove(Funcionario funcionario);

	public void update(Funcionario funcionario);
	
	public List<Funcionario> pesquisar(int matricula, String nome);
	

}