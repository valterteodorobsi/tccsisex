package dao;

import java.util.List;

import model.Funcao;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import util.HibernateUtil;

public class FuncaoDaoImp implements FuncaoDao {
	public void save(Funcao funcao) {

		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction t = session.beginTransaction();
		session.save(funcao);
		t.commit();
	}

	public Funcao getFuncao(int id) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		return (Funcao) session.load(Funcao.class, id);
	}

	public List<Funcao> list() {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction t = session.beginTransaction();
		List lista = session.createQuery("from Funcao ").list();
		t.commit();
		return lista;
	}

	public void remove(Funcao funcao) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction t = session.beginTransaction();
		session.delete(funcao);
		t.commit();
	}

	public void update(Funcao funcao) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction t = session.beginTransaction();
		session.update(funcao);

		t.commit();
	}

	public List<Funcao> pesquisar(int ID_FUNCAO, String nome) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction t = session.beginTransaction();
		Query query = session
				.createQuery("FROM Funcao u where u.ID_FUNCAO = :id_funcao OR u.NOME = :nome"); // mondar
																										// query
																										// para
																										// lyke
		query.setParameter("id_funcao", ID_FUNCAO);																								// depois
		query.setParameter("nome", nome);
		t.commit();
		return query.list();

	}
}
