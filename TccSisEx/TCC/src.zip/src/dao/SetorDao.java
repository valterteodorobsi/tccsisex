package dao;

import model.Setor;
import java.util.List;

public interface SetorDao {

	public void save(Setor setor);

	public Setor getSetor(int id);

	public List<Setor> list();

	public void remove(Setor setor);

	public void update(Setor setor);
	
	public List<Setor> pesquisar(Integer ID_CENTRO_CUSTO, String nome);
	

}