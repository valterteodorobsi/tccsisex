package dao;

import java.util.List;

import model.Exame;

public interface ExameDao {

	public void save(Exame exame);

	public Exame getExame(int id);

	public List<Exame> list();

	public void remove(Exame exame);

	public void update(Exame exame);
	
	public List<Exame> pesquisar(Integer id_exame, String nome_exame);
	

}