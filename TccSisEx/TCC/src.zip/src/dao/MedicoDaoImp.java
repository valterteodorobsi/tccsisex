package dao;

import java.util.List;

import model.Medico;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import util.HibernateUtil;

public class MedicoDaoImp implements MedicoDao {

	public void save(Medico Medico) {

		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction t = session.beginTransaction();
		session.save(Medico);
		t.commit();
	}

	public Medico getMedico(int id) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		return (Medico) session.load(Medico.class, id);
	}

	public List<Medico> list() {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction t = session.beginTransaction();
		List lista = session.createQuery("from Medico").list();
		t.commit();
		return lista;
	}

	public void remove(Medico Medico) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction t = session.beginTransaction();
		session.delete(Medico);
		t.commit();
	}

	public void update(Medico Medico) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction t = session.beginTransaction();
		session.update(Medico);
		
		t.commit();
	}
	public List<Medico> pesquisar(int matricula, String nome) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction t = session.beginTransaction();
		Query query = session.createQuery("FROM Medico u where u.ID_MATRICULA = :matricula OR u.NOME = :nome"); // mondar query para lyke depois
		query.setParameter("matricula", matricula);
		query.setParameter("nome", nome);
		t.commit();
		return query.list();
		
	}
}