package dao;

import model.PedidoDeExame;

public interface PedidoDeExameDao {

	public void save(PedidoDeExame pedidoDeExame);

	
}
