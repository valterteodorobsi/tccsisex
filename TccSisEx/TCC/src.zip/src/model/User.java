/**
 * 
 */
package model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * SisEx - Sistema de Gerenciamento de Exames
 * 
 * @project SisEx
 * @package br.com.sisex.entity
 * @class User.java
 * @author Marco Quadros (hanrellz - marco.quadros@mqsistemas.com.br)
 * @version 1.0
 * 
 */
@Entity
@Table(name = "TBL_Usuarios")
public class User {

	@Id
	@Column(name = "ROW_ID_USUARIO", nullable=false)
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	@Column(name = "NOME_COMPLETO_USUARIO", nullable=false)
	private String nomeCompleto;

	@Column(name = "LOGIN_USUARIO", nullable=false)
	private String login;

	@Column(name = "PASSWD_USUARIO", nullable=false)
	private String passwd;

	@Column(name = "ATIVO_USUARIO", nullable=false)
	private int ativo;

	@Column(name = "EMAIL_USUARIO", nullable=false)
	private String email;

	@Column(name = "DATA_CADASTRO_USUARIO", nullable=false)
	private Date dataCadastro;

	@Column(name = "NIVEL_USUARIO", nullable=false)
	private int nivelAcesso;

	/**
	 * @return id
	 */
	public Long getId() {
		return id;
	}

	/**
	 * @param id
	 *            the id to set
	 */
	public void setId(Long id) {
		this.id = id;
	}

	/**
	 * @return nomeCompleto
	 */
	public String getNomeCompleto() {
		return nomeCompleto;
	}

	/**
	 * @param nomeCompleto
	 *            the nomeCompleto to set
	 */
	public void setNomeCompleto(String nomeCompleto) {
		this.nomeCompleto = nomeCompleto;
	}

	/**
	 * @return login
	 */
	public String getLogin() {
		return login;
	}

	/**
	 * @param login
	 *            the login to set
	 */
	public void setLogin(String login) {
		this.login = login;
	}

	/**
	 * @return passwd
	 */
	public String getPasswd() {
		return passwd;
	}

	/**
	 * @param passwd
	 *            the passwd to set
	 */
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}

	/**
	 * @return ativo
	 */
	public int getAtivo() {
		return ativo;
	}

	/**
	 * @param ativo
	 *            the ativo to set
	 */
	public void setAtivo(int ativo) {
		this.ativo = ativo;
	}

	/**
	 * @return email
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * @param email
	 *            the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * @return dataCadastro
	 */
	public Date getDataCadastro() {
		return dataCadastro;
	}

	/**
	 * @param dataCadastro
	 *            the dataCadastro to set
	 */
	public void setDataCadastro(Date dataCadastro) {
		this.dataCadastro = dataCadastro;
	}

	/**
	 * @return nivelAcesso
	 */
	public int getNivelAcesso() {
		return nivelAcesso;
	}

	/**
	 * @param nivelAcesso
	 *            the nivelAcesso to set
	 */
	public void setNivelAcesso(int nivelAcesso) {
		this.nivelAcesso = nivelAcesso;
	}
}
